import { useState } from 'react'
import Sidebar from './components/layout/Sidebar'
import Header from './components/layout/Header'
import WelcomeBanner from './components/dashboard/WelcomeBanner'
import WeatherCard from './components/dashboard/WeatherCard'
import StatCards from './components/dashboard/StatCards'
import PluckingTrendChart from './components/dashboard/PluckingTrendChart'
import FieldWiseDonut from './components/dashboard/FieldWiseDonut'
import TopFieldsList from './components/dashboard/TopFieldsList'
import WorkerAttendance from './components/dashboard/WorkerAttendance'
import RecentActivities from './components/dashboard/RecentActivities'
import EstateMap from './components/dashboard/EstateMap'
import QuickActions from './components/dashboard/QuickActions'
import DashboardFooter from './components/dashboard/DashboardFooter'

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleToggleSidebar = () => {
    // Desktop: collapse to icons | Mobile: open/close drawer
    if (window.matchMedia('(min-width: 1024px)').matches) {
      setSidebarCollapsed((v) => !v)
    } else {
      setMobileOpen((v) => !v)
    }
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {mobileOpen && (
        <button
          type="button"
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          aria-label="Close sidebar overlay"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <Sidebar
        collapsed={sidebarCollapsed}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
        <Header onToggleSidebar={handleToggleSidebar} />

        <main className="min-h-0 flex-1 space-y-3 overflow-x-hidden overflow-y-auto p-3 sm:space-y-4 sm:p-4 lg:p-6">
          {/* Welcome + Weather */}
          <div className="grid grid-cols-1 gap-3 sm:gap-4 lg:grid-cols-12 lg:items-stretch">
            <div className="lg:col-span-8">
              <WelcomeBanner />
            </div>
            <div className="lg:col-span-4">
              <WeatherCard />
            </div>
          </div>

          {/* Stat cards */}
          <StatCards />

          {/* Charts row */}
          <div className="grid grid-cols-1 gap-3 sm:gap-4 md:grid-cols-2 lg:grid-cols-12">
            <div className="md:col-span-2 lg:col-span-5">
              <PluckingTrendChart />
            </div>
            <div className="lg:col-span-4">
              <FieldWiseDonut />
            </div>
            <div className="lg:col-span-3">
              <TopFieldsList />
            </div>
          </div>

          {/* Attendance + Activities + Map */}
          <div className="grid grid-cols-1 gap-3 sm:gap-4 md:grid-cols-2 lg:grid-cols-12">
            <div className="lg:col-span-3">
              <WorkerAttendance />
            </div>
            <div className="lg:col-span-4">
              <RecentActivities />
            </div>
            <div className="md:col-span-2 lg:col-span-5">
              <EstateMap />
            </div>
          </div>

          {/* Quick actions */}
          <QuickActions />

          <DashboardFooter />
        </main>
      </div>
    </div>
  )
}
